<?php

return [
    'db' => [
        'host'    => '127.0.0.1',
        'port'    => 3306,
        'name'    => 'pasabuy',
        'user'    => 'root',
        'pass'    => '',
        'charset' => 'utf8mb4',
    ],
    'app' => [
        'name'  => 'PasaBuy Mo, Pasaya Mo',
        // 'url'   => 'http://192.168.100.4/pasabuy/api',
        // 'url'   => 'http://10.231.117.154/pasabuy/api',

        'url' => 'https://pasabuy.isuc-ccsict.com/api',
        'debug' => true,
    ],
    'fees' => [
        'admin_rate' => 0.02,
        'debt_warn_threshold'    => 200,   // warn user at ₱200+
        'debt_block_threshold'   => 500,   // block posting at ₱500+
        'debt_block_days'        => 30,    // block posting if any fee > 30 days old
    ],
    'payment' => [
        'gcash_number' => '0917-123-4567',           // admin's GCash
        'gcash_name'   => 'PasaBuy Official',        // account name
    ],
    'mail' => [
        'host'       => 'smtp.gmail.com',
        'port'       => 587,
        'username'   => 'anywherefind2@gmail.com',
        'password'   => 'bken kxvu pcsf zhuo',   // Gmail App Password
        'encryption' => 'tls',                    // STARTTLS
        'from_email' => 'anywherefind2@gmail.com',
        'from_name'  => 'PasaBuy Mo, Pasaya Mo',
    ],
    'storage' => [
        'ids'  => __DIR__ . '/../storage/ids',
        'logs' => __DIR__ . '/../storage/logs',
    ],
    'fcm' => [
        'service_account' => __DIR__ . '/firebase-service-account.json',
    ],
];
